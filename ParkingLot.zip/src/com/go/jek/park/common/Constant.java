/**
 * 
 */
package com.go.jek.park.common;

/**
 * @author braj.kishore
 *
 */
public interface Constant {

	String COMMAND_CREATE_PARK="create_parking_lot";
	String COMMAND_GETIN_PARK="park";
	String COMMAND_GETOUT_PARK="leave";
	String COMMAND_STATUS_PARK="status";
	String COMMAND_WHITE_COLOR_REG_CARS="registration_numbers_for_cars_with_colour";
	String COMMAND_WHITE_COLOR_CAR_SLOTS="slot_numbers_for_cars_with_colour";
	String COMMAND_CAR_SLOT="slot_number_for_registration_number";
	
}
