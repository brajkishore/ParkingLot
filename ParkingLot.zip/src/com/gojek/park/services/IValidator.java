/**
 * 
 */
package com.gojek.park.services;

/**
 * @author braj.kishore
 *
 */
public interface IValidator {

	boolean validate(String value);
	
}
