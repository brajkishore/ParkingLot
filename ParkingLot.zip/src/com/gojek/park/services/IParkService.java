/**
 * 
 */
package com.gojek.park.services;

/**
 * @author braj.kishore
 *
 */
public interface IParkService {

	void processCommand(String command, String value1, String value2);

}
