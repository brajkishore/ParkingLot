/**
 * 
 */
package com.gojek.park.model;

/**
 * @author braj.kishore
 *
 */
public class ParkLot {

	private Integer slotNum;
	private Car car;
	/**
	 * @return the slotNum
	 */
	public Integer getSlotNum() {
		return slotNum;
	}
	/**
	 * @param slotNum the slotNum to set
	 */
	public void setSlotNum(Integer slotNum) {
		this.slotNum = slotNum;
	}
	/**
	 * @return the car
	 */
	public Car getCar() {
		return car;
	}
	/**
	 * @param car the car to set
	 */
	public void setCar(Car car) {
		this.car = car;
	}
	
	
	
	
	
}
